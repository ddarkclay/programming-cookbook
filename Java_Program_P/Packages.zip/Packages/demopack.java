import mypack.*;

class demopack
{
   public static void main(String args[])
   {
      multi1 m = new multi1(2,3);

      System.out.println(m.calmult());

   }
}