package packmaths;

public class Div
{
   int a;
   int b;

	public Div(int x,int y)
	{
	    a=x;
	    b=y;
	}
	
	public int makeDiv()
	{
	   return a/b;
	}   
}