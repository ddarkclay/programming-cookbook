package packmaths;

public class Multiplication
{
   int a;
   int b;

	public Multiplication(int x,int y)
	{
	    a=x;
	    b=y;
	}
	
	public int makeMultiplication()
	{
	   return (a*b);
	} 
}