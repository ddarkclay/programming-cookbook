import mypackage.*;

class Palintest
{
  public static void main(String args[])
  {
     Palindrome p = new Palindrome();
 
    System.out.println(p.test(args[0]));
  }
}