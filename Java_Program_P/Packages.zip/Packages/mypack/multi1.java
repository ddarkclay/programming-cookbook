package mypack;

public class multi1
{
   public int a,b;

   public multi1(int x,int y)
   {
     a = x;
     b = y;
    }
   public int calmult()   
   {
     return a*b;
   }
}